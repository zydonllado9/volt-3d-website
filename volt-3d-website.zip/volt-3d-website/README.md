# VOLT — Energy in Motion

A responsive product showcase inspired by the provided reference: dark editorial styling, neon magenta lighting, an interactive 3D-style can, bold typography, and scroll-based product storytelling.

## Files
- `index.html` — page sections and semantic markup
- `css/style.css` — responsive layout, visual styling, CSS can fallback, and motion
- `js/main.js` — Three.js can scene, mobile navigation, scroll reveals, flavor interactions

## Preview locally
Serve the folder over HTTP instead of opening `index.html` directly. For example, run `python -m http.server 8000` in the project folder and open `http://localhost:8000`.

The 3D can uses Three.js from jsDelivr and web fonts from Google Fonts, so those features require an internet connection. A CSS-rendered can remains visible as a fallback if WebGL is unavailable. The flavor cards are concept art, not claims about actual retail products.

## GitHub Pages
In the repository, open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
