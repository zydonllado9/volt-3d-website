import * as THREE from "three";

const canHost = document.querySelector("#can-scene");
const fallback = canHost?.querySelector(".fallback-can");
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// If WebGL is unavailable, the CSS-rendered can remains visible.
function buildCanScene() {
  if (!canHost || !window.WebGLRenderingContext) return;
  try {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
    camera.position.set(0, 0.15, 8.3);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    canHost.appendChild(renderer.domElement);
    renderer.domElement.setAttribute("aria-hidden", "true");
    Object.assign(renderer.domElement.style, { position: "absolute", inset: "0", width: "100%", height: "100%", zIndex: "3" });
    if (fallback) fallback.style.opacity = "0";

    const group = new THREE.Group(); scene.add(group);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xd900b9, metalness: 0.56, roughness: 0.24, emissive: 0x46003e, emissiveIntensity: 0.36 });
    group.add(new THREE.Mesh(new THREE.CylinderGeometry(0.91, 0.84, 3.35, 96, 1), bodyMat));
    const topMat = new THREE.MeshStandardMaterial({ color: 0xbfc1cb, metalness: 0.92, roughness: 0.2 });
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.83, 0.83, 0.11, 96), topMat); top.position.y = 1.69; group.add(top);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.81, 0.055, 12, 96), topMat); rim.rotation.x = Math.PI / 2; rim.position.y = 1.73; group.add(rim);
    const bottom = new THREE.Mesh(new THREE.TorusGeometry(0.77, 0.055, 12, 96), topMat); bottom.rotation.x = Math.PI / 2; bottom.position.y = -1.64; group.add(bottom);

    const labelCanvas = document.createElement("canvas"); labelCanvas.width = 512; labelCanvas.height = 1024;
    const ctx = labelCanvas.getContext("2d");
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, "#6d0064"); grad.addColorStop(0.42, "#ed00d0"); grad.addColorStop(0.7, "#a00092"); grad.addColorStop(1, "#48003c");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 512, 1024);
    ctx.fillStyle = "#fff"; ctx.textAlign = "center"; ctx.font = "bold 36px Arial"; ctx.fillText("ENERGY / 01", 256, 120);
    ctx.save(); ctx.translate(256, 530); ctx.rotate(-Math.PI / 2); ctx.font = "900 170px Arial"; ctx.fillText("VOLT", 0, 44); ctx.restore();
    ctx.font = "bold 82px Arial"; ctx.fillText("ϟ", 256, 690); ctx.font = "bold 25px Arial"; ctx.fillText("ORIGINAL ENERGY", 256, 775);
    ctx.font = "22px Arial"; ctx.fillText("250 ML  ·  8.4 FL OZ", 256, 955);
    const texture = new THREE.CanvasTexture(labelCanvas); texture.colorSpace = THREE.SRGBColorSpace;
    const label = new THREE.Mesh(new THREE.CylinderGeometry(0.916, 0.846, 3.31, 96, 1, true, -Math.PI / 2.3, Math.PI / 1.15), new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide }));
    group.add(label);

    const keyLight = new THREE.PointLight(0xffb6f3, 80); keyLight.position.set(4, 4, 5); scene.add(keyLight);
    const pinkLight = new THREE.PointLight(0xf500dd, 70); pinkLight.position.set(-4, 1, 2); scene.add(pinkLight);
    const rimLight = new THREE.PointLight(0x7e28ff, 45); rimLight.position.set(2, 0, -3); scene.add(rimLight);
    scene.add(new THREE.AmbientLight(0xffffff, 1.0));

    const resize = () => { const width = canHost.clientWidth || 500, height = canHost.clientHeight || 500; renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix(); };
    resize(); window.addEventListener("resize", resize, { passive: true });
    let targetX = 0, targetY = -0.13;
    canHost.addEventListener("pointermove", e => { const box = canHost.getBoundingClientRect(); targetY = ((e.clientX - box.left) / box.width - 0.5) * 0.65; targetX = ((e.clientY - box.top) / box.height - 0.5) * 0.25; });
    canHost.addEventListener("pointerleave", () => { targetX = 0; targetY = -0.13; });
    const clock = new THREE.Clock();
    function animate() {
      if (!document.hidden) { const t = clock.getElapsedTime(); group.rotation.y += ((targetY + (prefersReducedMotion ? 0 : Math.sin(t * 0.34) * 0.08)) - group.rotation.y) * 0.035; group.rotation.x += (targetX - group.rotation.x) * 0.035; if (!prefersReducedMotion) group.position.y = Math.sin(t * 0.8) * 0.1; renderer.render(scene, camera); }
      requestAnimationFrame(animate);
    }
    animate();
  } catch (err) { console.warn("VOLT 3D preview unavailable; using CSS artwork.", err); if (fallback) fallback.style.opacity = "1"; }
}
buildCanScene();

const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".desktop-nav");
toggle?.addEventListener("click", () => { const open = nav?.classList.toggle("open") ?? false; toggle.setAttribute("aria-expanded", String(open)); });
nav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => { nav.classList.remove("open"); toggle?.setAttribute("aria-expanded", "false"); }));

const revealTargets = document.querySelectorAll(".product-layout, .manifesto h2, .flavor-card, .final-cta h2");
revealTargets.forEach(el => el.classList.add("reveal"));
if ("IntersectionObserver" in window && !prefersReducedMotion) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add("visible"); observer.unobserve(entry.target); } }), { threshold: 0.13 });
  revealTargets.forEach(el => observer.observe(el));
} else revealTargets.forEach(el => el.classList.add("visible"));

document.querySelectorAll(".flavor-select").forEach(button => button.addEventListener("click", () => {
  const card = button.closest(".flavor-card"); card?.classList.toggle("selected");
  const selected = card?.classList.contains("selected"); button.textContent = selected ? "✓" : "↗"; button.setAttribute("aria-pressed", String(Boolean(selected)));
}));
const year = document.querySelector("#year"); if (year) year.textContent = String(new Date().getFullYear());
